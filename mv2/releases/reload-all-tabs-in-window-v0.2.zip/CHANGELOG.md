## v0.2

Added sidebar action for marking tabs to skip during reload.
Added context menu to easily access sidebar.

## v0.1

Simple browser action with icon.
