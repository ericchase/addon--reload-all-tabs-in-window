## v0.3b

Updated icons and options page.  
Minor fixes across the extension.

## v0.3

Added instructions to sidebar action.  
Added 'Reset' and 'Skip All' buttons.  
Added visual feedback to list items and buttons.

## v0.2

Added sidebar action for marking tabs to skip during reload.  
Added context menu to easily access sidebar.

## v0.1

Simple browser action with icon.
